/**
 * Created by Roman on 14/7/2015.
 */
var module = angular.module('starter', ['ionic','ngStorage']);

module.controller('TrnCtrl',function($http,$scope, $sessionStorage){

    //--------------------------------------------------------------
    //-- When          Who         Description
    //-- ============  ==========  =================================
    //-- 16/07/2015    R.W.
    //--------------------------------------------------------------
    $scope.init = function(){

        $scope.getTransportShutleList();

        $scope.upcoming_shatle = web_config.upcoming_shatle_title;
        $scope.next_btn = web_config.next_btn;
        $scope.prev_btn = web_config.prev_btn;
        $scope.iterator = 0;
        $scope.weekend_message = web_config.weekend_message;
        $scope.img_source = web_config.img_source;
    };
    //-----------------------------------------------------------------
    //-- When          Who         Description
    //-- ============  ==========  ====================================
    //-- 22/07/2015    R.W         list of function created after data
    //                             received.
    //-----------------------------------------------------------------
    $scope.listOfFunctionAfterDataRecived = function(){
        $scope.getTransportWeekDay();
        $scope.getTransportDate();
        $scope.setShowTransportList();
        $scope.setUpcomingShuttle();
    }
    //-----------------------------------------------------------------
    //-- When          Who         Description
    //-- ============  ==========  ====================================
    //-----------------------------------------------------------------
    $scope.getTransportShutleList = function(){

        $http({ url        :  web_config.msso_url,
            method     :  "POST",
            data       : {
                "Request": {
                    "RequestHeader": {
                        "ServiceName": "GetTransportTime",
                        "AppID": "MobileApp",
                        "EnvCode": "MobileApp_QA",
                        "Timeout": "30"
                    },
                    "InParams" : {
                        "User": $sessionStorage.user,
                        "Token": $sessionStorage.token
                    }
                }
            },
            headers: {'Content-Type': 'application/json'}
        }).success(function (data, status, headers) {
            $scope.checkEaiData(data);
            $scope.list = data;
            $scope.listOfFunctionAfterDataRecived();

        }).error(function (data, status, headers) {
            $scope.status = status + ' ' + headers;
        });
    };
    //-----------------------------------------------------------------
    //-- When          Who         Description
    //-- ============  ==========  ====================================
    //-----------------------------------------------------------------
    $scope.checkServiceData = function(data){

    };
    //-----------------------------------------------------------------
    //-- When        Who        Description
    //-- ==========  =========  =======================================
    //-- 21/07/2015  R.W.       get WAZE URL
    //-----------------------------------------------------------------
    $scope.getWazeUrl = function(group){
        var wazeUrl;
        if(group == 1)
        {
            wazeUrl = "http://waze.to/li/hsv8wrvx3u";
        }
        if(group == 2)
        {
            wazeUrl ="http://waze.to/siiruW1WqPRm44mAi";

        }
        return wazeUrl;
    };
    //-----------------------------------------------------------------
    //-- When         Who         Description
    //-- ===========  ==========  =====================================
    //-- 06/30/2015   R.W.        If given group is the selected group
    //--                          , desel
    //-----------------------------------------------------------------
    $scope.getImgUrl = function(group){
        var imgUrl;
        if(group ==1 ){
            $scope.imgUrl = "img/hashalom_train_station_in_tel_aviv.jpg";
        }
        if(group == 2){
            $scope.imgUrl = "img/pelephone_vered.jpg";
        }
    };
    //-----------------------------------------------------------------
    //-- When         Who         Description
    //-- ===========  ==========  =====================================
    //-- 06/30/2015   R.W.        If given group is the selected group
    //--                          , desel
    //-----------------------------------------------------------------
    $scope.toggleGroup = function(group){

        if($scope.isGroupShown(group)) {
            $scope.shownGroup = null;
            $scope.wazeUrl = null;
        } else {

            $scope.shownGroup = group;
            $scope.wazeUrl = $scope.getWazeUrl();
        }
    };
    //-----------------------------------------------------------------
    //-- When         Who         Description
    //-- ===========  ==========  =====================================
    //-- 06/30/2015   R.W.        function calculate is accordion open
    //--                          or close
    //-----------------------------------------------------------------
    $scope.isGroupShown = function(group){
        return $scope.shownGroup === group;
    };
    //--------------------------------------------------------------
    //-- When         Who       Description
    //-- ===========  ========  ====================================
    //-- 30/06/2015   R.W.      function redirect user to Home Page
    //--------------------------------------------------------------
    $scope.forwardToWaze = function(group){
        var waze_url = web_config.waze_url_source[group];
        if (ionic.Platform.isAndroid()) {
            navigator.app.loadUrl(waze_url, {openExternal: true});
        } else if (ionic.Platform.isIOS()) {
            window.open(waze_url, '_system');
        }

    };
    //--------------------------------------------------------------
    //-- When        Who         Description
    //-- ==========  ==========  ===================================
    //-- 07/08/2015  R.W.        function return to head menu
    //--------------------------------------------------------------
    $scope.forwardToHome = function(wazeUrl){
         window.location = "./../../index.html" ;
    };
    //--------------------------------------------------------------
    //-- When            Who          Description
    //-- ==============  ===========  ==============================
    //-- 14/07/2015      R.W.         Calculate Linc to Train Page
    //--------------------------------------------------------------
    $scope.trainIsrPgLinc = function(){
      var pUrl = 'http://www.rail.co.il/HE/DrivePlan/Pages/DrivePlan.aspx?';
      var pOriginStationId = '&OriginStationId=4600';
      var pOriginStationName = '&OriginStationName=%D7%AA%22%D7%90-%D7%94%D7%A9%D7%9C%D7%95%D7%9D';
      var pHoursDeparture = '&HoursDeparture=';
      var pMinutesDeparture = '&MinutesDeparture=';

      var pFullUrl = pUrl + pOriginStationId + pOriginStationName + pHoursDeparture + pMinutesDeparture;

      if (ionic.Platform.isAndroid()) {
            navigator.app.loadUrl(pFullUrl , {openExternal: true});
      } else if (ionic.Platform.isIOS()) {
            window.open(pFullUrl, '_system');
      }

    };
    //--------------------------------------------------------------
    //-- When          Who         Description
    //-- ============  ==========  =================================
    //-- 16/07/2015    R.W.
    //--------------------------------------------------------------
    $scope.getTransportWeekDay = function() {

        var days = web_config.week_days;
        var today = new Date();
        var lIterator = $scope.iterator;
        var displayDate = new Date(today.getTime() + (lIterator * (24 * 60 * 60 * 1000)));

        $scope.transportWeekDay =  days[displayDate.getDay()];
    }
    //--------------------------------------------------------------
    //-- When          Who         Description
    //-- ============  ==========  =================================
    //-- 16/07/2015    R.W.        function calculate is display
    //--                           shutle data
    //--------------------------------------------------------------
    $scope.setShowTransportList = function(){
        var lIterator = $scope.iterator;
        var today = new Date();
        var displayDate = new Date(today.getTime() + (lIterator * (24 * 60 * 60 * 1000)));
        var day = displayDate.getDay().toString();
        if(day === "5" || day==="6")
        {
            $scope.showTransportList = 0;
        }
        else{
            $scope.showTransportList = 1;
        };
    };
    //--------------------------------------------------------------
    //-- When          Who         Description
    //-- ============  ==========  =================================
    //-- 16/07/2015    R.W.        function calculate date picker
    //--------------------------------------------------------------
    $scope.getTransportDate = function(){

        var today = new Date();
        var lIterator = $scope.iterator;
        var displayDate = new Date(today.getTime() + (lIterator *(24 * 60 * 60 * 1000)));


        var mm = (displayDate.getMonth() + 1).toString();
        if(mm.length < 2)
        {
            mm = '0' + mm;
        }
        var dd = (displayDate.getDate()).toString();
        if(dd.length < 2)
        {
            dd = '0' + dd;
        }
        var yyyy = (displayDate.getFullYear()).toString();
        var date = dd + '/' + mm + '/' + yyyy;
        $scope.transportDate =  date;
    };
    //--------------------------------------------------------------
    //-- When Who description
    //--------------------------------------------------------------
    $scope.TrnDateForward = function(){
        if( $scope.iterator < web_config.days)
        {
          $scope.iterator = $scope.iterator + 1;
        }
        $scope.getTransportWeekDay();
        $scope.getTransportDate();
        $scope.setShowTransportList();
    };
    //--------------------------------------------------------------
    //-- When Who description
    //--------------------------------------------------------------
    $scope.TrnDateBack = function(){
        if( $scope.iterator > 0)
        {
            $scope.iterator = $scope.iterator - 1;
        }
        $scope.getTransportWeekDay();
        $scope.getTransportDate();
        $scope.setShowTransportList();
    };
    //--------------------------------------------------------------
    //-- When         Who         Description
    //-- ===========  ==========  ==================================
    //-- 16/07/2015   R.W.        Function return upcoming shutle
    //--------------------------------------------------------------
    $scope.setUpcomingShuttle = function(){

        var list ;
        var new_today = new Date();
        var today = new Date(new_today.getTime() + (2 *(24 * 60 * 60 * 1000)));
        var upcomingShutleObj = {TITLE : "" ,BEGIN_DATE : '' , DIRECTION : "" , DAY_PERIOD : ""};
        var hours = today.getHours()
        var minutes = today.getMinutes();
        var time = (parseInt(hours) * 60) + parseInt(minutes);


        list = $scope.list.Response.OutParams.Terminal;


        var min = 1000;
        var begin_date;
        upcomingShutleObj.TITLE = web_config.upcoming_shatle_title;

        for(var i=0 ; i < list.length ; i++)
        {
            var sub_list = list[i].Time;
            for(var j=0 ; j < sub_list.length ; j++)
            {
              var list_date =  sub_list[j].BEGIN_DATE;
              var hour_array = list_date.split(":")
              var result_to_min = (parseInt(hour_array[0]) * 60) + parseInt(hour_array[1]);
              if(((result_to_min - time)> 0) && (min > (result_to_min - time)))
              {
                  min = (parseInt(time) - parseInt(result_to_min));
                  begin_date = sub_list[j].BEGIN_DATE + " . " + list[i].DIRECTION;
                  upcomingShutleObj.BEGIN_DATE = sub_list[j].BEGIN_DATE;
                  upcomingShutleObj.DIRECTION  = list[i].DIRECTION;
                  upcomingShutleObj.DAY_PERIOD = list[i].DAY_PERIOD;

              } // if

            } // for 2
        } // for 1
        if(upcomingShutleObj.BEGIN_DATE) {
            $scope.upcomingShuttle = upcomingShutleObj.TITLE + upcomingShutleObj.BEGIN_DATE;
            $scope.upcomingShuttleDayPeriod = upcomingShutleObj.DIRECTION + " . "+ upcomingShutleObj.DAY_PERIOD;
        }else{
            $scope.upcomingShuttle = upcomingShutleObj.TITLE + web_config.no_upcoming_shatle_title;
            $scope.upcomingShuttleDayPeriod = "";
        }


    }; // upcomingShuttle
    //------------------------------------------------------------------
    //-- When        Who          Description
    //-- ==========  ===========  ======================================
    //-- 22/07/2015  R.W.         when token not valis service faild and
    //                            return ErrorCode instead
    //                            Response.OutParams.Terminal return
    //                            Response.OutParams.ErrorCode
    //------------------------------------------------------------------
    $scope.checkEaiData = function(data){
        var ErrorCode = data.Response.OutParams.ErrorCode;
        if (ErrorCode)
        {
            window.location = "./../../index.html#/app/error" ;
        }
    }; // checkEaiData

});
