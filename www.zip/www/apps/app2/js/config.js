/**
 * Created by User on 16/07/2015.
 */
var web_config = {
    msso_url                 : "http://msso.pelephone.co.il/MobilePortalApp",
    next_btn                 : "קדימה",
    prev_btn                 : "אחורה",
    upcoming_shatle_title    : "הסעה קרובה : ",
    no_upcoming_shatle_title : " אין הסעות להיום.",
    days                     : "7",
    weekend_message          : "בימי שישי ושבת ההסעות לא מתקיימות",
    week_days                : ['ראשון', 'שני', 'שלישי', 'רביעי', 'חמישי', 'שישי', 'שבט'],
    img_source               : ["img/hashalom_train_station_in_tel_aviv.jpg","img/hashalom_train_station_in_tel_aviv.jpg","img/pelephone_vered.jpg"],
    waze_url_source          : ["" , "http://waze.to/li/hsv8wrvx3u" , "http://waze.to/siiruW1WqPRm44mAi"],
    /*
    list :{
        "Response": {
            "ResponseHeader": {
                "ServiceName": "GetTransportTime",
                "EAI_Status": "0"
            },
            "OutParams": {
                "Terminal": [
                    {
                        "DIRECTION": "מרכבת השלום לבית ורד",
                        "DAY_PERIOD": "בוקר",
                        "TYPE_ID": "1",
                        "Time": [
                            { "BEGIN_DATE": "07:10" },
                            { "BEGIN_DATE": "07:20" },
                            { "BEGIN_DATE": "07:30" },
                            { "BEGIN_DATE": "07:40" },
                            { "BEGIN_DATE": "07:50" },
                            { "BEGIN_DATE": "08:10" },
                            { "BEGIN_DATE": "08:20" },
                            { "BEGIN_DATE": "08:30" },
                            { "BEGIN_DATE": "08:40" },
                            { "BEGIN_DATE": "08:50" },
                            { "BEGIN_DATE": "09:00" },
                            { "BEGIN_DATE": "09:10" }
                        ]
                    },
                    {
                        "DIRECTION": "מבית ורד לרכבת השלום",
                        "DAY_PERIOD": "צהריים",
                        "TYPE_ID": "2",
                        "Time": [
                            { "BEGIN_DATE": "15:00" },
                            { "BEGIN_DATE": "15:20" },
                            { "BEGIN_DATE": "15:40" },
                            { "BEGIN_DATE": "16:00" },
                            { "BEGIN_DATE": "16:20" },
                            { "BEGIN_DATE": "16:40" },
                            { "BEGIN_DATE": "17:00" },
                            { "BEGIN_DATE": "17:10" },
                            { "BEGIN_DATE": "17:30" },
                            { "BEGIN_DATE": "17:50" },
                            { "BEGIN_DATE": "18:15" },
                            { "BEGIN_DATE": "18:35" },
                            { "BEGIN_DATE": "18:55" }
                        ]
                    }
                ]
            }
        }
    }
*/
}