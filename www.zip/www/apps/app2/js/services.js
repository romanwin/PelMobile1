/**
 * Created by User on 16/07/2015.
 */
var services = angular.module('starter', ['ionic','ionic-datepicker']);
services.factory('getFormatedDate', function(pDate){
    var mm = (pDate.getMonth() + 1).toString();
    if(mm.length < 2)
    {
        mm = '0' + mm;
    }
    var dd = (pDate.getDate()).toString();
    alert(dd.length);

    if(dd.length < 2)
    {
        dd = '0' + dd;
    }
    var yyyy = (pDate.getFullYear()).toString();
    var date = dd + '/' + mm + '/' + yyyy;
    alert(date);
    return date;
    });
