angular.module('starter', ['ionic','ngStorage','starter.services', 'starter.controllers','ngCordova', 'ngCookies'])
.run(function($ionicPlatform,$ionicLoading,$state,$rootScope,$sessionStorage,$localStorage,PelApi,Network,appSettings,$http) {

 
 Network.register() ;
       // Network.networkInit();
  $ionicLoading.show({
    content: 'Loading',
    animation: 'fade-in',
    showBackdrop: true,
    maxWidth: 200,
    showDelay: 0
  });


  //  $state.go('app.home')
  $ionicPlatform.ready(function() {

/*
  if($rootScope.isOnline) { 
        PelApi.login().success(function(data){
             $rootScope.WhoMI= data;
          }).error(function(data){          
              $rootScope.error= data;
              $state.go('app.error')
          });
  }; */

      if ( $sessionStorage.userMenu == undefined )
          {

              PelApi.getMenu(appSettings.usermenuAPIURL,appSettings.timeout).success(function (data) {
                  // $rootScope.WhoMI = data;
                  $sessionStorage.userMenu = data;
                  $sessionStorage.user = data.user;
                  $sessionStorage.token = data.token;
                  $localStorage.userMenu = data;
                  console.log("localStorage ", $localStorage.menu);
              }).error(function (data,status) {
                  if ($localStorage.userMenu) {
                    $rootScope.WhoMI = $localStorage.userMenu;
                  }
                  else{
                      console.log("in error 2");
                    $rootScope.error = appSettings.getUserMenuError + " " + status;
                    $state.go('app.error')
                  };
              });

          }else{
            $rootScope.WhoMI = $sessionStorage.userMenu;
      };
      console.log($rootScope.WhoMI);
      //var url = "http://msso.pelephone.co.il/MobileServices/SSOService.svc/json/GetUserMenu/0523344901";
      //var url = "http://10.174.5.185/MobileServices/SSOService.svc/json/GetUserMenu/0523344901";

  /* the next http call was replaced by above code - call to PelApi.getMenu factory
      $http({
          url: appSettings.usermenuAPI,
          method: "GET",
          headers: {'Content-Type': 'application/json; charset=utf-8 '}
      }).success(function (data, status, headers) {
          $rootScope.WhoMI = data;
         // console.log($rootScope.WhoMI);
          $sessionStorage.usertoken = data.token;
          $sessionStorage.userMenu = data;
         console.log($sessionStorage.userMenu);
      }).error(function (data, status, headers) {
         // $scope.status = status + ' ' + headers;
          console.log("Menu data error");
          console.log( status + ' ' + headers);
      });
*/


  $ionicLoading.hide() ;
   if (window.cordova && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
    }
    if (window.StatusBar) {
      // org.apache.cordova.statusbar required
      StatusBar.styleDefault();
    }
  });

})

.config(function($stateProvider, $urlRouterProvider) {
  $stateProvider

  .state('app', {
    url: "/app",
    abstract: true,
    templateUrl: "templates/menu.html",
    controller: 'AppCtrl'
  })
   .state('app.subapp', {
    url: "/subapp/:appid",
     views: {
      'mainContent': {
      controller:'AppCtrl',
        templateUrl: "templates/app.html"
      }
    }
  })
  .state('app.home', {
    url: "/home/:appid",
    views: {
      'mainContent': {
        templateUrl: "templates/home.html"
      }
    }
  }).state('app.pincode', {
    url: "/pincode/:appid",
    views: {
      'mainContent': {
        controller:'UnlockController',
        templateUrl: "templates/pincode.html"
      }
    }
  }).state('app.error', {
    url: "/error",
    views: {
      'mainContent': {
        templateUrl: "templates/error.html"
      }
    }
  });

  $urlRouterProvider.otherwise('/app/home/');

});
