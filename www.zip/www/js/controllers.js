angular.module('starter.controllers',[])
.controller('AppCtrl', function($rootScope , $stateParams,$scope, $ionicModal, $state,$ionicSideMenuDelegate,$cordovaInAppBrowser,Network,Session) {
 $rootScope.stateParam = {} ;

  /*
  $scope.init  = function() {
    if($stateParams.appid) { 
      var app =  {}  ; 
      $rootScope.WhoMI.menu.forEach(function(i) { 
          if(i.id  == $stateParams.appid )
          app = i ;  
      });

      $scope.appSwitch(app);
    }
  }  ; */

  var iabOptions = {
      location: 'yes',
      clearcache: 'yes',
      toolbar: 'yes'
    };

    $scope.logout  = function() { 
      ionic.Platform.exitApp();
    } ;
        console.log("Before device");

    $scope.initDevice  = function() {
      Network.networkInit();

    } ;

        console.log('after ALEXALEX');
    $scope.appSwitch  = function(i) {

      if($rootScope.isOffline && i.WorkState==="online") {
        return false;
      };
      console.log("i.Pin " + i.Pin  + " " + Session.pinApproved);
      if(i.Pin && !Session.pinApproved() ) {
        $ionicSideMenuDelegate.toggleRight();
        $rootScope.stateParam.app = i.Path ;
       //$state.go("app.pincode",{appid:i.id});
          $state.go("app.pincode",{appid: i.Path});
        return false;
      }

      var target = i.target || "_blank";
          if(i.url) {
              $cordovaInAppBrowser.open(i.url, target,iabOptions)
               .then(function(event) {
                 // success
               }, function(event) {
                 // error
              });
              return false;
          } else if(i.Path) {
              var path = "apps/" + i.Path + "/app.html";
              window.location = path;
          } 

      };

}).controller('HomeCtrl', function($rootScope , $scope ,PelApi ) {
}).controller('UnlockController', function($scope, $stateParams,$state,$location, $timeout,Session,PelApi,helpers) {
 
    $scope.init = function() {
      $scope.passcode = "";
    }

   console.log("stateParams.app" ,$stateParams.appid);
    $scope.add = function(value) {
      if($scope.passcode.length < 4) {
            $scope.passcode = $scope.passcode + value;
            if($scope.passcode.length == 4) {

                $timeout(function() {
                    console.log("The four digit code was entered");

                    PelApi.sendPincode($scope.passcode).
                        success(function(data) {
                          if(data.status) {
                                  $state.go('app.subapp',{appid:$stateParams.appid});
                          }
                          helpers.flash("הקוד שהזנת אינו נכון") ;

                        }).
                        error(function(data, status, headers, config) {
                            if(status === 0) {
                               // $http timeout
                             } 
                             helpers.flash("תקלה באימות קוד אישי") ;
                             //$state.go('app.subapp',{appid:$stateParams.appid});
                             $scope.err = config;
                        });
                }, 500);
            }
        }
    }
 
    $scope.delete = function() {
       if($scope.passcode.length > 0) {
        $scope.passcode = $scope.passcode.substring(0, $scope.passcode.length - 1);
      }
    }
 
});;
