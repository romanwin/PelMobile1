var services = angular.module('starter.services',['ngStorage']);
services.constant('appSettings', {
        api:"http://msso.pelephone.co.il/PCBarCode/PrintCenterBar.asmx/WhoMI" ,
        usermenuAPIURL:"http://msso.pelephone.co.il/MobileServices/SSOService.svc/json/GetUserMenu",
        sapi:"https://msso.pelephone.co.il/PCBarCode/PrintCenterBar.asmx/WhoMI" ,
        timeout:1000 ,
        /*WhoMI : {username:"golanh",
              menu: [
                      {id:1,label:"App-online-pin",dir:"app1",pin:true},
                      {id:2,label:"App2-offline",dir:"app2",offline:true} ,
                      {id:3,label:"App3",dir:"app3",offline:false} ,
                      {id:4,label:"App4",dir:"app4"} ,
                      {id:5,label:'External' , url : "http://emp.pelephone.co.il"}
                    ]
              }, */
        flashTime: 2500 ,
        getUserMenuError: "שגיאת קבלת התפריטים למשתמש, קוד שגיאה - "

    });
services.factory('helpers',function($timeout,$rootScope,appSettings) {

        function flash (msg) {
              console.log('1 ', appSettings.flashTime);
              $rootScope.flash = msg ; 
               $timeout(function() {
                  $rootScope.flash  = "";
                 }, appSettings.flashTime);
        }

        function empty(data)
          {
            if(typeof(data) == 'number' || typeof(data) == 'boolean')
            {
              return false;
            }
            if(typeof(data) == 'undefined' || data === null)
            {
              return true;
            }
            if(typeof(data.length) != 'undefined')
            {
              return data.length == 0;
            }
            var count = 0;
            for(var i in data)
            {
              if(data.hasOwnProperty(i))
              {
                count ++;
              }
            }
            return count == 0;
          } 
      return {empty :empty , 
              flash:flash}
    }).factory('PelApi',['$http',function($http,$rootScope,$sessionStorage,appSettings) {
        return {

            authenticate: function () {

            },

            sendPincode: function (pincode) {
                return $http({
                    url:appSettings.api ,
                    method:"POST" ,
                    data: {pincode:pincode},

                    timeout:appSettings.timeout,
                    headers: {'Content-Type': 'application/json; charset=utf-8' }
                });
            },
            getData:function(params) {
                return $http({
                    url:appSettings.api ,
                    method:"POST" ,
                    data: {},
                    timeout:appSettings.timeout,
                    headers: {'Content-Type': 'application/json; charset=utf-8' }
                });
            }   ,
            login: function() {
                return $http({
                    url:appSettings.api ,
                    method:"POST" ,
                    data: {},
                    timeout:appSettings.timeout,
                    headers: {'Content-Type': 'application/json; charset=utf-8' }
                });
            }   ,
            getMenu: function (menuUrl,serviceTimeOut) {
                return   $http({
                    url: menuUrl, //appSettings.usermenuAPIURL, //app_config.usermenuAPI,
                    method: "GET",
                    timeout : serviceTimeOut ,//app_config.timeout ,
                    headers: {'Content-Type': 'application/json; charset=utf-8 '}
                }).success(function (data, status, headers) {
                    console.log("succes", data);
                }).error(function (data, status, headers) {
                   // console.log("appSettings " , appSettings.usermenuAPIURL);
                    console.log('data');
                    console.log(data);
                    console.log('status');
                    console.log(status);
                    console.log('headers');
                    console.log(headers);

              });
            }
        };
    }]).
    factory('Network',['$cordovaNetwork','$rootScope','$interval','PelApi',function($cordovaNetwork,$rootScope,$interval,PelApi) {


    var networkInit =  function() {

      $rootScope.isOffline = true; 
      $rootScope.networkType = "noconnection";

       $rootScope.networkType  = $cordovaNetwork.getNetwork() ;
       console.log("$rootScope.networkType");
       console.log($rootScope.networkType);

       var stop = $interval(function() {
                 $rootScope.networkType = $cordovaNetwork.getNetwork() ;
           console.log("$rootScope.networkType",$rootScope.networkType);
         },5000) ;

        $rootScope.$on('$destroy', function() {
                $interval.cancel(stop);
         });


        $rootScope.$watch('networkType', function(newStatus,oldStatus) {
            console.log("watch");
            if(newStatus.match(/\dG/i)) {
                 $rootScope.isOnline = true; 
                 $rootScope.isOffline = false;

                // PelApi.getMenu();
             }  else {
                 $rootScope.isOffline = false; 
                 $rootScope.isOffline = true;

             }

        });


  } ; 

  var register  = function() {

   document.addEventListener("deviceready", networkInit,false);
  } ;
   
 return {
      
      register: register,
      networkInit : networkInit

    }
}]).factory('Session' , ['$cookies', 'helpers',function($cookies,helpers)  {
    
    var pinApproved  =  $cookies.pinApproved  ;
   
    return {
      pinApproved : function() {
        if( helpers.empty(pinApproved)  )
        return false ;
        return true ;
    } , 
    set :function(k,v) {
        $cookies[k] = v  ;
        return true ; 
    } , 
     get :function(k,v) {
        return $cookies[k] ;
    } , 
    remove :function(k,v) {
        delete $cookies[k] ;
        return true ; 
    } 
   } 
}]);
