/**
 * Created by User on 23/07/2015.
 */
var app_config111 = {
    usermenuAPI: "http://msso.pelephone.co.il/MobileServices/SSOService.svc/json/GetUserMenu",
    timeout : 1000
};
